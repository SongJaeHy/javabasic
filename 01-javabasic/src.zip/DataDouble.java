
public class DataDouble {
	public static void main(String[] args) {
		// 실수 표현을 할 때는 float, double 자료형을 씁니다.
		// 기본적으로 실수 숫자만 작성하면 double입니다.
		// 만약 float으로 실수 숫자를 표현한다면
		// 숫자 가장 오른쪽에 f라고 적어줍니다.
		// float 4바이트, double은 8바이트입니다.
		float a = 1.1f;
		double b = 1.1;
		System.out.println(a);
		System.out.println(b);
	}
}
