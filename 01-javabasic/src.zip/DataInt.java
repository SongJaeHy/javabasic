
public class DataInt {
	// 정수형을 나타낼 수 있는 자료형은 크게 4가지입니다.
	// byte, short, int, long형입니다.
	// 변수 선언시 지정 자료형을 위의 키워드로 지정합니다.
	public static void main(String[] args) {
		byte a = 127;
		short b = 32000;
		int c =3;
		long d = 4;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}
