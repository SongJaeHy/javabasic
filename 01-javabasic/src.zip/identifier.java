
public class identifier {
	public static void main(String[] args) {
		//변수는 일종의 자료를 담을 수 있는 박스입니다.
		//자료를 담기 전에 어떤 자료가 담길지 미리 약속을 해야 합니다.
		int a =5; // 정수 숫자 5를 a박스에 담겠다.
		int A = 10;     // 정수 숫자 20을 A박스에 담겠다.
		int number = 15; //정수 숫자 15흫 number박스에 담겠다.
		System.out.println(a); // a 박스 내부 값 콘솔에 출력
		System.out.println(A); // A박스 내부 값 콘솔에 출력
		System.out.println(number); //number박스 내부 값 콘솔 출력
		//System.out.println(B); //B는 선언된적이 없어서 출력이 안됨
	}
}
