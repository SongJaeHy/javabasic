
public class Q1 {
	public static void main(String[] args) {
		int a;
		
		int x,y;
		a = 100;
		x = 200;
		y = 300;
		System.out.println(a+x+y);
	}
}
